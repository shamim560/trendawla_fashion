<footer>
<p>&copy; 2025 Trendwala. All rights reserved.</p>
</footer>

<script src="assets/js/main.js"></script>
</body>
</html>

CREATE DATABASE IF NOT EXISTS trendwala_db;
USE trendwala_db;

CREATE TABLE IF NOT EXISTS products (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    price DECIMAL(10,2) NOT NULL,
    image VARCHAR(255) NOT NULL,
    category VARCHAR(50) NOT NULL
);

CREATE TABLE IF NOT EXISTS orders (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_name VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    address TEXT NOT NULL,
    total DECIMAL(10,2) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO products (name, price, image, category) VALUES
('Product 1',1200,'assets/images/product1.png','shirts'),
('Product 2',1500,'assets/images/product2.png','shirts'),
('Product 3',1800,'assets/images/product3.png','pants'),
('Product 4',2000,'assets/images/product4.png','shirts'),
('Product 5',2200,'assets/images/product5.png','pants'),
('Product 6',2500,'assets/images/product6.png','shirts'),
('Product 7',2700,'assets/images/product7.png','pants'),
('Product 8',3000,'assets/images/product8.png','shirts'),
('Product 9',3200,'assets/images/product9.png','pants'),
('Product 10',3500,'assets/images/product10.png','shirts');
